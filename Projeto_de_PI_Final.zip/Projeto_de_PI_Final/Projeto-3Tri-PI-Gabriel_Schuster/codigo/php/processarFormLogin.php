<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.95">
    <title>VinteAutoblog - Login</title>
    <link rel="stylesheet" href="../css/styleProcessarLogin.css">
    <link rel="shortcut icon" href="../img/iconeSite.ico" type="image/x-icon">
</head>

<body>

    <div id="cabCima">
        <!-- Logo! -->
        <a id="logo" href="../index.html"><img src="../img/logo.png" alt=""></a>

        <form id="formBarraBusca" action="../php/pesquisa-na-tela.php" method="post" enctype="multipart/form-data">
            <input type="text" name ="busca" id="barraBusca" placeholder="Buscar">
        </form>
        
        <!-- Div do menu -->
        <div><a href="../html/login.html"><img class="icones" src="../img/perfil.png" alt=""></a></div>
        <div><a href="../php/listarDuvidas.php"><img class="icones" src="../img/notificacoes.png" alt=""></a></div>
    </div>

    <div id="divMenu">
        <nav id="navMenu">
            <div class="botoes"><a href="../index.html">INÍCIO</a></div>
            <div class="botoes"><a href="../php/listarNoticias.php">NOTÍCIAS</a></div>
            <div class="botoes"><a href="../php/listarGaleria.php">GALERIA</a></div>
            <div class="botoes"><a href="../html/duvidas.html">DÚVIDAS</a></div>
            <div class="botoes"><a href="../html/sobre.html">SOBRE</a></div>

        </nav>
    </div>
    
    <div id="conteudo">
        <div id="caixaForm">
            <?php
            include "funcoes.php";

            if (empty($_POST['usuario']) || empty($_POST['senha'])) {
                echo "<div class = 'divTitulo'><h2 class ='titulo'>Incorreto, tente novamente</h2></div>";
                echo "<div class = 'divBotoes'>";
                            echo "<div id ='btnConfirmar'><a href='../html/login.html'>Voltar</a></div>";
                    echo "</div>";
            } else {
                // Obtém o termo
                $usuario = $_POST['usuario'];
                $senha = $_POST['senha'];

                if (login($usuario, $senha) == true) {
                    echo "<div class = 'divTitulo'><h2 class ='titulo'>Logado com sucesso</h2></div>";
                    echo "<div class = 'divBotoes'>";
                            echo "<div id ='btnConfirmar'><a href='../php/form-uploadNoticia.php'>Inserir Noticia</a></div>";
                            echo "<div id ='btnConfirmar'><a href='../php/form-uploadGaleria.php'>Inserir Imagem</a></div>";
                    echo "</div>";
                } else {
                    echo "<div class = 'divTitulo'>Nao foi possivel logar</div>";
                    echo "<div id = 'btnConfirmar'><a href =''>voltar</a></div>";
                }
            }

            ?>
        </div>
    </div>
    
</body>

</html>