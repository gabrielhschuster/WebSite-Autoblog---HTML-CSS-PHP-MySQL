<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Formulario para carregar imagens</title>
</head>

<body>
    <fieldset>
        <legend>Formulário Upload de Imagem:</legend>
        <form action="processarFormGaleria.php" method="post" enctype="multipart/form-data">
            <label>Imagem:</label>
            <input type="file" name="arquivo_imagem">
            <input type="submit" value="Salvar">

        </form>
    </fieldset>

</body>

</html>