<?php
include "funcoes.php";
$auxConexao = conectar();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.95">
    <title>VinteAutoblog - Galeria</title>
    <link rel="stylesheet" href="../css/styleGaleria.css">
    <link rel="shortcut icon" href="../img/iconeSite.ico" type="image/x-icon">
</head>

<body>

    <div id="cabCima">
        <!-- Logo! -->
        <a id="logo" href="../index.html"><img src="../img/logo.png" alt=""></a>

        <form id="formBarraBusca" action="../php/pesquisa-na-tela.php" method="post" enctype="multipart/form-data">
            <input type="text" name ="busca" id="barraBusca" placeholder="Buscar">
        </form>

        <!-- Div do menu -->
        <div><a href="../html/login.html"><img class="icones" src="../img/perfil.png" alt=""></a></div>
        <div><a href="../php/listarDuvidas.php"><img class="icones" src="../img/notificacoes.png" alt=""></a></div>
    </div>

    <div id="divMenu">
        <nav id="navMenu">
            <div class="botoes"><a href="../index.html">INÍCIO</a></div>
            <div class="botoes"><a href="../php/listarNoticias.php">NOTÍCIAS</a></div>
            <div class="botoes"><a href="../php/listarGaleria.php">GALERIA</a></div>
            <div class="botoes"><a href="../html/duvidas.html">DÚVIDAS</a></div>
            <div class="botoes"><a href="../html/sobre.html">SOBRE</a></div>

        </nav>
    </div>
    <div id="conteudo">
        <div id="espacoGaleria">
            <?php
            $conexao = new PDO("mysql:host=localhost;dbname=vinteautoblog", "root", "");

            $resultados = [];

            echo "<br><h1 class='titulo'>GALERIA</h1><br>";

            $sql = "SELECT * FROM galeria";
            $stmt = $auxConexao->prepare($sql);
            $stmt->execute();
            $imagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

            
            echo "<div class='divGrid'>";
            foreach ($imagens as $imagem) {
                echo "<div class='caixaImagens'>";

                if (!empty($imagem['imagem'])) {
                    $imgBase64 = base64_encode($imagem['imagem']);
                    echo "<img class='imagemGaleria' src='data:image/jpeg;base64,$imgBase64'>";
                }

                echo "</div>";
            }

            echo "</div>"; ?>

        </div>

    </div>
</body>

</html>