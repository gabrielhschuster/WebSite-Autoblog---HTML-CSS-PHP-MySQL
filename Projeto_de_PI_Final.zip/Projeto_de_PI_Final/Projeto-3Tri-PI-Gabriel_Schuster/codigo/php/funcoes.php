<?php

function conectar(): object
{
    $localServidor = "localhost";
    $nomeBaseDados = "vinteautoblog";
    $usuario = "root";
    $senha = "";

    try {
        $conexao = new PDO("mysql:host=$localServidor;dbname=$nomeBaseDados", $usuario, $senha);
    } catch (PDOException $e) {
        echo "Falha na conexão:" . $e->getMessage();
    }

    return $conexao;
}


function inserirDuvida(object $conexao, string $nome, $duvida, $descricao, $email): bool
{

    $comandoSQL = "insert into contato (nome, duvida, descricao, email) values(?,?,?,?)";

    $dados = $conexao->prepare($comandoSQL);

    $dados->bindParam(1, $nome);
    $dados->bindParam(2, $duvida);
    $dados->bindParam(3, $descricao);
    $dados->bindParam(4, $email);
    if ($dados->execute()) {
        return true;
    } else {
        return false;
    }
}

function mostrarProdutosComImagens(object $conexao): void
{

    $comandoSQL = "select * from servicos";
    $retornoBanco = $conexao->prepare($comandoSQL);
    $retornoBanco->execute();
    $registros = $retornoBanco->fetchAll(PDO::FETCH_OBJ);

    foreach ($registros as $linha) {
        echo 'DIRETO DO BANCO DE DADOS: ' . $linha->data . '<br>';
        echo 'FORMATANDO NO NOSSO PADRÃO:' . date("d/m/Y", strtotime($linha->data)) . '<br>';
        if ($linha->imagem <> null) {
            echo "<figure>";
            echo '<img src="data:;base64,' . base64_encode($linha->imagem) . '" width="200" height=""/>';
            echo "</figure>";
        }
    }
    return;
}

function mostrarDuvidas(object $conexao): void
{

    $comandoSQL = "select * from contato";
    $retornoBanco = $conexao->prepare($comandoSQL);
    $retornoBanco->execute();
    $registros = $retornoBanco->fetchAll(PDO::FETCH_OBJ);

    foreach ($registros as $linha) {
        echo "<div class= 'caixaDuvida'>";
            echo "<div class= 'divTitulo'>";
            echo "<h3>" . htmlspecialchars($linha->duvida) . "</h3>";
            echo "</div>";

            echo "<div class= 'divNome'>";
            echo "<h3 class='descricao'>Nome: " . htmlspecialchars($linha->nome) . "</h3>";
            echo "</div>";

            echo "<div class= 'divDescricao'>";
            echo "<h3 class='descricao'>Descrição: " . htmlspecialchars($linha->descricao) . "</h3>";
            echo "</div>";

            echo "<div class= 'divEmail'>";
            echo "<h3 class='descricao'>Email: " . htmlspecialchars($linha->email) . "</h3>";
            echo "</div>";
        echo "</div>";
    }
    return;
}

function mostrarResultado(array $resultados, string $termo_busca): void
{
    // Verifica se o array $resultados não está vazio
    if (count($resultados) > 0) {
        // Mostra para qual termo a busca foi feita (COM SEGURANÇA)
        echo "<p>Mostrando resultados para: <strong>" . ($termo_busca) .
            "</strong></p>";
        // Loop para exibir cada produto
        foreach ($resultados as $noticia) {

            echo "<div class='caixaResultado'>";

            echo "<div class='divTitulo'>" . ($noticia['titulo']) . "</div>";

            if (!empty($noticia['imagem'])) {
                $imagemBase64 = base64_encode($noticia['imagem']);
                $tipoImagem = 'image/jpeg'; // !! MUDE ISSO se suas imagens forem PNG, GIF, etc.

                echo "<div class='divImagem'><img src='data:" . $tipoImagem . ";base64," . $imagemBase64 . "' alt='Imagem de " . ($noticia['titulo']) . "></div>";
                 echo "<div class ='divDescricao'>Descrição:" . ($noticia['descricao']) . "</div>";
            } else {
                echo "<p>(Produto sem imagem)</p>";
            }
            
           
        }
    } else {
        // Se o array $resultados estiver vazio
        echo "<p class='sem-resultados'>Nenhum produto encontrado com o termo: <strong>" . ($termo_busca) . "</strong></p>";
    }
}


function inserindoImagemGaleria($conexao, $arquivo_blob)
{
    $comandoSQL = "insert into galeria (imagem) values(?)";

    $dados = $conexao->prepare($comandoSQL);

    $dados->bindParam(1, $arquivo_blob);
    if ($dados->execute()) {
        return true;
    } else {
        return false;
    }
}

function inserirNoticia(object $conexao, string $titulo, $arquivo_blob, $descricao, $data): bool
{

    $comandoSQL = "insert into noticias (titulo, imagem, descricao, data) values(?,?,?,?)";

    $dados = $conexao->prepare($comandoSQL);

    $dados->bindParam(1, $titulo);
    $dados->bindParam(2, $arquivo_blob, PDO::PARAM_LOB);
    $dados->bindParam(3, $descricao);
    $dados->bindParam(4, $data);
    if ($dados->execute()) {
        return true;
    } else {
        return false;
    }
}

function login(string $usuario, string $senha)
{
    if ($usuario != "admin" && $senha != "123") {
        return false;
    } else {
        return true;
    }
}

function informacoesNoticia($conexao, $id)
{
    $comandoSQL = "select * from noticias where id = $id";
    $retornoBanco = $conexao->prepare($comandoSQL);
    $retornoBanco->execute();
    $registros = $retornoBanco->fetchAll(PDO::FETCH_OBJ);

    foreach ($registros as $noticia) {
        echo "<div class= 'divTitulo'>";

        echo "<h3>" . htmlspecialchars($noticia->titulo) . "</h3>";
        echo "</div>";

        if (!empty($noticia->imagem)) {
            $imgBase64 = base64_encode($noticia->imagem);
            echo "<div class= 'divImagem'>";
            echo "<a href='../index.html'><img class='imagemNoticia' src='data:image/jpeg;base64,$imgBase64'></a>";
            echo "</div>";
        } else {
            echo "<div class='img-sem-foto'>Sem imagem</div>";
        }

        echo "<div class= 'divDescricao'>";
        echo "<h3 class='descricao'>" . htmlspecialchars($noticia->descricao) . "</h3>";
        echo "</div>";

        echo "<div class= 'divData'>";
        echo "<h3 class='data'>Data: " . date("d/m/Y", strtotime($noticia->data)) . '<br>';
        echo "</div>";
    }
    return;

}