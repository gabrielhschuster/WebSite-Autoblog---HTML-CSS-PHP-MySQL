<?php
include "funcoes.php";
$auxConexao = conectar();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.95">
    <title>VinteAutoblog - Login</title>
    <link rel="stylesheet" href="../css/styleNoticiasDetalhadas.css">
    <link rel="shortcut icon" href="../img/iconeSite.ico" type="image/x-icon">
</head>

<body>

    <div id="cabCima">
        <!-- Logo! -->
        <a id="logo" href="../index.html"><img src="../img/logo.png" alt=""></a>

        <form id="formBarraBusca" action="../php/pesquisa-na-tela.php" method="post" enctype="multipart/form-data">
            <input type="text" name ="busca" id="barraBusca" placeholder="Buscar">
        </form>

        <!-- Div do menu -->
        <div><a href="../html/login.html"><img class="icones" src="../img/perfil.png" alt=""></a></div>
        <div><a href="../php/listarDuvidas.php"><img class="icones" src="../img/notificacoes.png" alt=""></a></div>
    </div>

    <div id="divMenu">
        <nav id="navMenu">
            <div class="botoes"><a href="../index.html">INÍCIO</a></div>
            <div class="botoes"><a href="../php/listarNoticias.php">NOTÍCIAS</a></div>
            <div class="botoes"><a href="../php/listarGaleria.php">GALERIA</a></div>
            <div class="botoes"><a href="../html/duvidas.html">DÚVIDAS</a></div>
            <div class="botoes"><a href="../html/sobre.html">SOBRE</a></div>

        </nav>
    </div>
    <div id="conteudo">
        <div id="espacoNoticia">
            <?php
            $id = $_GET['id'] ?? 0;

            $sql = "SELECT * FROM noticias WHERE id = :id";
            $stmt = $auxConexao->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $noticias = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo "<br><h2 class='titulo'>Notícias</h2><br>";
            echo "<div class='espacoNoticia'>";

            foreach ($noticias as $noticia) {

                $id = $noticia['id'];

            
                informacoesNoticia($auxConexao, $id);

            }

            echo "</div>";


            ?>

        </div>

    </div>
    <div id="cabBaixo">

    </div>
</body>

</html>