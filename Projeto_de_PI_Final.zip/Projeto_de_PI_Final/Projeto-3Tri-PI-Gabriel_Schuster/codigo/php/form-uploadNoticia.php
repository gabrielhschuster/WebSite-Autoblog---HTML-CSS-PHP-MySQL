<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Formulario para carregar imagens</title>
</head>

<body>
    <fieldset>
        <legend>Formulário Upload de Imagem:</legend>
        <form action="../php/processarForm-Noticia.php" method="post" enctype="multipart/form-data">
                <div id="backgroundCampos">
                    <div class="campos">Titulo <br>
                        <input type="text" name="titulo"><br>
                    </div>
                    
                    <div class="campos"> imagem <br>
                        <input type="file" name="arquivo_imagem"><br>
                    </div>
                    <div class="campos">descricao <br>
                        <input type="text" name="descricao"><br>
                    </div>
                    <div class="campos"> Data <br>
                        <input type="date" name="data">
                    </div>
                </div>


                <input id="btnConfirmar" type="submit" value="Enviar">

            </form>
    </fieldset>

</body>

</html>