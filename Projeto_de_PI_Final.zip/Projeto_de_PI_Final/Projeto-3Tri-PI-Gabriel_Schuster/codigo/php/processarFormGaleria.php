<?php
include "funcoes.php";
$auxConexao = conectar();
$arquivo = $_FILES['arquivo_imagem'];
$arquivo_blob = file_get_contents($arquivo['tmp_name']);
$retornoDaFuncaoInserir = inserindoImagemGaleria($auxConexao, $arquivo_blob);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    if ($retornoDaFuncaoInserir == true) {
        echo "Inserido com
sucesso";
    } else {
        echo "Nao foi possivel inserir!!!";
    }
    ?>
    <a href="listarprodutos.php">Listar Produtos!!!! </a>
</body>

</html>