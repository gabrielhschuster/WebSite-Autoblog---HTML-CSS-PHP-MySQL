<?php
include "funcoes.php"; // Inclui suas funções conectar() e mostrarResultado()
$conexao = conectar();
$resultados = [];
$termo_busca = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['busca'])) {
    // --- AÇÃO 1: BUSCA NO BANCO DE DADOS (Quando o usuário aperta "Enter") ---
    $termo_busca = trim($_POST['busca']);
    $termo_like = "%" . $termo_busca . "%";
    try {
        $sql = "SELECT * FROM noticias WHERE titulo LIKE ? OR descricao LIKE ?";
        $stmt = $conexao->prepare($sql);
        $stmt->execute([$termo_like, $termo_like]);
        $resultados = $stmt->fetchAll();
    } catch (PDOException $e) {
        echo "Erro na busca: " . $e->getMessage();
    }
} else {
    // --- AÇÃO 2: CARGA INICIAL (Quando a página abre pela primeira vez) ---
// Carrega os 20 produtos mais recentes para o filtro JS ter o que filtrar
    try {
        $sql = "SELECT * FROM noticias ORDER BY id DESC LIMIT 20";
        $stmt = $conexao->prepare($sql);
        $stmt->execute();
        $resultados = $stmt->fetchAll();
    } catch (PDOException $e) {
        echo "Erro ao carregar produtos iniciais: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busca Híbrida</title>
    <link rel="stylesheet" href="../css/styleBarraPesquisa.css">
    <link rel="shortcut icon" href="../img/iconeSite.ico" type="image/x-icon">
</head>

<body>
    <div class="container">

        <div id="cabCima">
            <!-- Logo! -->
            <a id="logo" href="../index.html"><img src="../img/logo.png" alt=""></a>

            <form id="formBarraBusca" action="../php/pesquisa-na-tela.php" method="post" enctype="multipart/form-data">
                <input type="text" name="busca" id="barraBusca" placeholder="Buscar">
            </form>


            <!-- Div do menu -->
            <div><a href="../html/login.html"><img class="icones"
                        src="../img/perfil.png" alt=""></a></div>
            <div><a href="../php/listarDuvidas.php"><img class="icones" src="../img/notificacoes.png"
                        alt=""></a>
            </div>
        </div>

        <div id="divMenu">
            <nav id="navMenu">
                <div class="botoes"><a href="../index.html">INÍCIO</a></div>
                <div class="botoes"><a href="../php/listarNoticias.php">NOTÍCIAS</a></div>
                <div class="botoes"><a href="../php/listarGaleria.php">GALERIA</a></div>
                <div class="botoes"><a href="../html/duvidas.html">DÚVIDAS</a></div>
                <div class="botoes"><a href="../html/sobre.html">SOBRE</a></div>

            </nav>
        </div>


        <div id="conteudo">
            <div id="espacoResultados">
 
                <h3 id = "tituloPagina">Resultados</h3>
                <div id="listaResultados">
                    <?php
                    // Se o formulário foi enviado, usa o $termo_busca
                    // Se não, passa uma string vazia (na carga inicial)
                    $termo_usado = $termo_busca ?? '';
                    mostrarResultado($resultados, $termo_usado);
                    ?>
                </div>

            </div>


        </div>
    </div>
    <script>
        function filtrarNaTela() {
            // 1. Pega o que o usuário digitou no filtro (em maiúsculas)
            var filtro = document.getElementById("busca").value.toUpperCase();
            // 2. Pega o container da lista
            var lista = document.getElementById("listaResultados");
            // 3. Pega todos os itens ".resultado" que estão dentro da lista
            var itens = lista.getElementsByClassName("resultado");
            // 4. Faz um loop por todos os itens
            for (var i = 0; i < itens.length; i++) {
                var item = itens[i];
                // Pega o texto completo do item
                var textoItem = item.textContent || item.innerText;
                // 5. Verifica se o texto do item contém o texto do filtro
                if (textoItem.toUpperCase().indexOf(filtro) > -1) {
                    // Se contém, mostra o item (remove a classe)

                    item.style.display = "";
                    // ou item.classList.remove("item-escondido");

                } else {
                    // Se não contém, esconde o item (adiciona a classe)

                    item.style.display = "none"; // ou item.classList.add("item-escondido");

                }

            }
        }
    </script>
</body>

</html>